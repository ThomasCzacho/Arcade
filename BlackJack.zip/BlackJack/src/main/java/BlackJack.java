public class BlackJack {


    Card ha0 = new Card("Hearts","ACE",0 ); // 1 13 hearts
    Card hn2 = new Card("Hearts",null,2 ); // 2 13 hearts
    Card hn3 = new Card("Hearts",null,3 ); // 3 13 hearts
    Card hn4 = new Card("Hearts",null,4 ); // 4 13 hearts
    Card hn5 = new Card("Hearts",null,5 ); // 5 13 hearts
    Card hn6 = new Card("Hearts",null,6 ); // 6 13 hearts
    Card hn7 = new Card("Hearts",null,7 ); // 7 13 hearts
    Card hn8 = new Card("Hearts",null,8 ); // 8 13 hearts
    Card hn9 = new Card("Hearts",null,9 ); // 9 13 hearts
    Card hn10 = new Card("Hearts",null,10 ); // 10 13 hearts
    Card hk0 = new Card("Hearts","King",0 ); // 11 13 hearts
    Card hq0 = new Card("Hearts","Queen",0 ); // 12 13 hearts
    Card hj0 = new Card("Hearts","Jack",0 ); // 13 13 hearts

    Card ca0 = new Card("Clubs","ACE",0 ); // 1 13 clubs
    Card cn2 = new Card("Clubs",null,2 ); // 2 13 clubs
    Card cn3 = new Card("Clubs",null,3 ); // 3 13 clubs
    Card cn4 = new Card("Clubs",null,4 ); // 4 13 clubs
    Card cn5 = new Card("Clubs",null,5 ); // 5 13 clubs
    Card cn6 = new Card("Clubs",null,6 ); // 6 13 clubs
    Card cn7 = new Card("Clubs",null,7 ); // 7 13 clubs
    Card cn8 = new Card("Clubs",null,8 ); // 8 13 clubs
    Card cn9 = new Card("Clubs",null,9 ); // 9 13 clubs
    Card cn10 = new Card("Clubs",null,10 ); // 10 13 clubs
    Card ck0 = new Card("Clubs","King",0 ); // 11 13 clubs
    Card cq0 = new Card("Clubs","Queen",0 ); // 12 13 clubs
    Card cj0 = new Card("Clubs","Jack",0 ); // 13 13 clubs

    Card sa0 = new Card("Spades","ACE",0 ); // 1 13 spades
    Card sn2 = new Card("Spades",null,2 ); // 2 13 spades
    Card sn3 = new Card("Spades",null,3 ); // 3 13 spades
    Card sn4 = new Card("Spades",null,4 ); // 4 13 spades
    Card sn5 = new Card("Spades",null,5 ); // 5 13 spades
    Card sn6 = new Card("Spades",null,6 ); // 6 13 spades
    Card sn7 = new Card("Spades",null,7 ); // 7 13 spades
    Card sn8 = new Card("Spades",null,8 ); // 8 13 spades
    Card sn9 = new Card("Spades",null,9 ); // 9 13 spades
    Card sn10 = new Card("Spades",null,10 ); // 10 13 spades
    Card sk0 = new Card("Spades","King",0 ); // 11 13 spades
    Card sq0 = new Card("Spades","Queen",0 ); // 12 13 spades
    Card sj0 = new Card("Spades","Jack",0 ); // 13 13 spades

    Card da0 = new Card("Diamonds","ACE",0 ); // 1 13 spades
    Card dn2 = new Card("Diamonds",null,2 ); // 2 13 spades
    Card dn3 = new Card("Diamonds",null,3 ); // 3 13 spades
    Card dn4 = new Card("Diamonds",null,4 ); // 4 13 spades
    Card dn5 = new Card("Diamonds",null,5 ); // 5 13 spades
    Card dn6 = new Card("Diamonds",null,6 ); // 6 13 spades
    Card dn7 = new Card("Diamonds",null,7 ); // 7 13 spades
    Card dn8 = new Card("Diamonds",null,8 ); // 8 13 spades
    Card dn9 = new Card("Diamonds",null,9 ); // 9 13 spades
    Card dn10 = new Card("Diamonds",null,10 ); // 10 13 spades
    Card dk0 = new Card("Diamonds","King",0 ); // 11 13 spades
    Card dq0 = new Card("Diamonds","Queen",0 ); // 12 13 spades
    Card dj0 = new Card("Diamonds","Jack",0 ); // 13 13 spades

    Card[] deck = {ha0,hn2,hn3,hn4,hn5,hn6,hn7,hn8,hn9,hn10,hk0,hq0,hj0,
                   ca0,cn2,cn3,cn4,cn5,cn6,cn7,cn8,cn9,cn10,ck0,cq0,cj0,
                   sa0,sn2,sn3,sn4,sn5,sn6,sn7,sn8,sn9,sn10,sk0,sq0,sj0,
                   da0,dn2,dn3,dn4,dn5,dn6,dn7,dn8,dn9,dn10,dk0,dq0,dj0,};
// first char is suit, second char is title, third char is value

}
