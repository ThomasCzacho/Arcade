public class Main {


}


/*STORY: you forgot
your girlfriend's anniversary present, and your paycheck comes tomorrow.
 you will have to win her a present at the run-down local arcade with only
 what's in your pockets. Your relationship depends on how good you can play.

 the arcade is filthy and old, there's only two functional machines left,
 however there's the perfect anniversary present, a pristine, 6 foot tall
 stuffed teddy bear holding a giant heart. It might be impossible to get
 that many tickets with what you have, but you'll have to try.
 */